exports.memoryOverload = async (event, context) => {
    return new Array(1e9).fill("OutOfMemory");
};
