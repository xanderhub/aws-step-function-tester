exports.genericError = (event, context) => {
    throw new Error("Test - Generic Error");
};