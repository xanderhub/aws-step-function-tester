exports.delay = async (event, context) => {
    return await new Promise(resolve => setTimeout(resolve, 3000));
};
